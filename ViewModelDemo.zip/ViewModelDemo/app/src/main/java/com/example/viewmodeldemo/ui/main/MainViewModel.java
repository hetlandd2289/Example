package com.example.viewmodeldemo.ui.main;

import androidx.lifecycle.ViewModel;

public class MainViewModel extends ViewModel {

    //Variable declarations
    private static final float rate = 0.87F;
    private String dollarText = "";
    private float result = 0F;

    //Method to get input and assign to dollarText
    public void setAmount(String value)
    {
        this.dollarText = value;
        result = Float.parseFloat(dollarText) * rate;
    }

    //Method to return the result for use
    public float getResult()
    {
        return result;
    }
}